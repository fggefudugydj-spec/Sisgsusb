package com.example.imported

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

data class ImportedApkInfo(
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val mainActivity: String,
    val themeResId: Int,
    val libName: String,
    val apkSizeBytes: Long,
    val importedAt: Long
)

/**
 * Keeps a private, independent copy of a user-supplied Minecraft APK
 * (e.g. the Trial edition). It never touches any installed Minecraft app.
 */
object ImportedApkStore {

    const val EXPECTED_ACTIVITY = "com.mojang.minecraftpe.MainActivity"
    private const val ABI = "arm64-v8a"
    private const val MAIN_LIB_ENTRY = "lib/arm64-v8a/libminecraftpe.so"

    fun rootDir(context: Context): File = File(context.filesDir, "imported")
    fun currentDir(context: Context): File = File(rootDir(context), "current")
    fun apkFile(context: Context): File = File(currentDir(context), "base.apk")
    fun libDir(context: Context): File = File(currentDir(context), "lib/$ABI")
    private fun infoFile(context: Context): File = File(currentDir(context), "info.json")
    fun runtimeLogFile(context: Context): File = File(rootDir(context), "mc_runtime.log")

    fun readInfo(context: Context): ImportedApkInfo? {
        return try {
            val f = infoFile(context)
            if (!f.exists() || !apkFile(context).exists()) return null
            val j = JSONObject(f.readText())
            ImportedApkInfo(
                packageName = j.getString("packageName"),
                versionName = j.optString("versionName", "?"),
                versionCode = j.optLong("versionCode", 0L),
                mainActivity = j.getString("mainActivity"),
                themeResId = j.optInt("themeResId", 0),
                libName = j.optString("libName", "minecraftpe"),
                apkSizeBytes = j.optLong("apkSizeBytes", 0L),
                importedAt = j.optLong("importedAt", 0L)
            )
        } catch (t: Throwable) {
            null
        }
    }

    fun clear(context: Context) {
        currentDir(context).deleteRecursively()
    }

    private fun querySize(context: Context, uri: Uri): Long {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getLong(0) else -1L
            } ?: -1L
        }.getOrDefault(-1L)
    }

    fun importFromUri(
        context: Context,
        uri: Uri,
        onProgress: (String, Float) -> Unit
    ): Result<ImportedApkInfo> {
        val root = rootDir(context)
        root.mkdirs()
        val tmp = File(root, "tmp_${System.currentTimeMillis()}")
        return try {
            if (Build.SUPPORTED_64_BIT_ABIS.none { it == ABI }) {
                error("هذا الجهاز لا يدعم arm64-v8a")
            }
            tmp.mkdirs()
            val apk = File(tmp, "base.apk")
            val total = querySize(context, uri)
            if (total > 0 && tmp.usableSpace < total * 2 + 200L * 1024 * 1024) {
                error("المساحة غير كافية. تحتاج مساحة تقارب ضعف حجم الملف.")
            }

            // 1) Copy the APK into private storage
            onProgress("جاري نسخ الملف...", 0f)
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(apk).use { out ->
                    val buf = ByteArray(256 * 1024)
                    var copied = 0L
                    var lastReport = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        copied += n
                        if (total > 0 && copied - lastReport > 8L * 1024 * 1024) {
                            lastReport = copied
                            onProgress("جاري نسخ الملف...", (copied.toFloat() / total) * 0.5f)
                        }
                    }
                    out.flush()
                }
            } ?: error("تعذر فتح الملف المختار")

            // 2) Validate + extract native libs
            onProgress("جاري فحص الملف...", 0.5f)
            val libOut = File(tmp, "lib/$ABI")
            libOut.mkdirs()
            ZipFile(apk).use { zip ->
                if (zip.getEntry(MAIN_LIB_ENTRY) == null) {
                    val nested = zip.entries().asSequence().any { it.name.endsWith(".apk") }
                    if (nested) {
                        error("هذا الملف حزمة مجمّعة (xapk/apks). المطلوب ملف APK واحد.")
                    }
                    error("الملف لا يحتوي $MAIN_LIB_ENTRY. تأكد أنه APK نسخة ماين كرافت لمعالج 64 بت.")
                }
                val libEntries = zip.entries().asSequence()
                    .filter { !it.isDirectory && it.name.startsWith("lib/$ABI/") && it.name.endsWith(".so") }
                    .toList()
                libEntries.forEachIndexed { index, entry ->
                    val target = File(libOut, entry.name.substringAfterLast('/'))
                    zip.getInputStream(entry).use { ins ->
                        FileOutputStream(target).use { outS -> ins.copyTo(outS, 256 * 1024) }
                    }
                    onProgress(
                        "استخراج المكتبات (${index + 1}/${libEntries.size})",
                        0.5f + 0.4f * ((index + 1).toFloat() / libEntries.size)
                    )
                }
            }

            // 3) Read the manifest data of the APK
            onProgress("قراءة معلومات الحزمة...", 0.92f)
            @Suppress("DEPRECATION")
            val pi = context.packageManager.getPackageArchiveInfo(
                apk.absolutePath,
                PackageManager.GET_ACTIVITIES or PackageManager.GET_META_DATA
            ) ?: error("تعذر قراءة معلومات الحزمة (الملف تالف أو غير مدعوم)")

            val act = pi.activities.orEmpty().firstOrNull { it.name == EXPECTED_ACTIVITY }
                ?: error(
                    "لم أجد $EXPECTED_ACTIVITY. الأنشطة الموجودة: " +
                        pi.activities.orEmpty().joinToString { it.name }
                )
            val libName = act.metaData?.getString("android.app.lib_name") ?: "minecraftpe"

            val info = ImportedApkInfo(
                packageName = pi.packageName,
                versionName = pi.versionName ?: "?",
                versionCode = PackageInfoCompat.getLongVersionCode(pi),
                mainActivity = act.name,
                themeResId = act.theme,
                libName = libName,
                apkSizeBytes = apk.length(),
                importedAt = System.currentTimeMillis()
            )
            File(tmp, "info.json").writeText(
                JSONObject().apply {
                    put("packageName", info.packageName)
                    put("versionName", info.versionName)
                    put("versionCode", info.versionCode)
                    put("mainActivity", info.mainActivity)
                    put("themeResId", info.themeResId)
                    put("libName", info.libName)
                    put("apkSizeBytes", info.apkSizeBytes)
                    put("importedAt", info.importedAt)
                }.toString()
            )

            // Android 14+ refuses to load writable dex/apk files
            apk.setReadOnly()

            // 4) Replace the previous import
            onProgress("إنهاء الاستيراد...", 0.98f)
            val current = currentDir(context)
            if (current.exists()) current.deleteRecursively()
            if (!tmp.renameTo(current)) error("تعذر حفظ الملف النهائي")
            onProgress("تم الاستيراد", 1f)
            Result.success(info)
        } catch (t: Throwable) {
            tmp.deleteRecursively()
            Result.failure(t)
        }
    }
}

package com.example.imported

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.res.AssetManager
import android.content.res.Resources
import android.os.Build
import android.os.Bundle
import android.view.ContextThemeWrapper
import dalvik.system.PathClassLoader
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Runs only inside the dedicated ":mc" process. It makes the imported APK's
 * code, native libraries and assets visible to this process so that
 * com.mojang.minecraftpe.MainActivity (declared in our manifest) can start.
 */
object McBootstrap {

    fun isMcProcess(): Boolean {
        return try {
            File("/proc/self/cmdline").readText().substringBefore('\u0000').endsWith(":mc")
        } catch (t: Throwable) {
            false
        }
    }

    fun log(context: Context, message: String) {
        try {
            val f = ImportedApkStore.runtimeLogFile(context)
            f.parentFile?.mkdirs()
            if (f.exists() && f.length() > 512 * 1024) f.delete()
            val ts = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            f.appendText("[$ts] $message\n")
        } catch (e: Throwable) {
        }
    }

    private fun exemptHiddenApis(context: Context) {
        if (Build.VERSION.SDK_INT < 28) return
        try {
            org.lsposed.hiddenapibypass.HiddenApiBypass.addHiddenApiExemptions("L")
            log(context, "Hidden API exemptions: OK")
        } catch (t: Throwable) {
            log(context, "Hidden API exemptions failed: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    /** Called from Application.attachBaseContext in the ":mc" process. */
    fun install(base: Context) {
        log(base, "=== :mc process starting (SDK ${Build.VERSION.SDK_INT}, ${Build.MODEL}) ===")
        val info = ImportedApkStore.readInfo(base)
        if (info == null) {
            log(base, "ERROR: no imported APK found. Import one first.")
            return
        }
        val apk = ImportedApkStore.apkFile(base)
        val libDir = ImportedApkStore.libDir(base)
        log(base, "APK: ${info.packageName} v${info.versionName} (${info.versionCode}), ${apk.length() / (1024 * 1024)} MB")

        exemptHiddenApis(base)

        try {
            val appLoader = base.classLoader
            val pluginLoader = PathClassLoader(apk.absolutePath, libDir.absolutePath, null)

            val bdc = Class.forName("dalvik.system.BaseDexClassLoader")
            val pathListField = bdc.getDeclaredField("pathList")
            pathListField.isAccessible = true
            val appList = pathListField.get(appLoader)!!
            val pluginList = pathListField.get(pluginLoader)!!

            mergeArrayField(appList, pluginList, "dexElements")
            log(base, "Merged dex elements (plugin first)")

            runCatching {
                mergeArrayField(appList, pluginList, "nativeLibraryPathElements")
                log(base, "Merged nativeLibraryPathElements")
            }.onFailure {
                log(base, "nativeLibraryPathElements merge failed: ${it.javaClass.simpleName}: ${it.message}")
            }

            runCatching {
                val f = appList.javaClass.getDeclaredField("nativeLibraryDirectories")
                f.isAccessible = true
                @Suppress("UNCHECKED_CAST")
                val cur = f.get(appList) as List<File>
                f.set(appList, listOf(libDir) + cur)
                log(base, "Added native lib dir: ${libDir.absolutePath}")
            }.onFailure {
                log(base, "nativeLibraryDirectories update failed: ${it.javaClass.simpleName}: ${it.message}")
            }

            try {
                val cls = appLoader.loadClass(info.mainActivity)
                log(base, "OK: class visible -> ${cls.name} (super=${cls.superclass?.name})")
            } catch (t: Throwable) {
                log(base, "ERROR: cannot load ${info.mainActivity}: ${t.javaClass.simpleName}: ${t.message}")
            }
        } catch (t: Throwable) {
            log(base, "ERROR during injection: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    private fun mergeArrayField(target: Any, source: Any, name: String) {
        val f = target.javaClass.getDeclaredField(name)
        f.isAccessible = true
        val a = f.get(target) as Array<*>
        val b = f.get(source) as Array<*>
        val comp = a.javaClass.componentType ?: error("no component type for $name")
        @Suppress("UNCHECKED_CAST")
        val merged = java.lang.reflect.Array.newInstance(comp, a.size + b.size) as Array<Any?>
        System.arraycopy(b, 0, merged, 0, b.size)
        System.arraycopy(a, 0, merged, b.size, a.size)
        f.set(target, merged)
    }

    /** Swaps the activity's resources/assets for the imported APK's and applies its theme. */
    fun prepareActivity(activity: Activity) {
        val info = ImportedApkStore.readInfo(activity) ?: return
        try {
            val apk = ImportedApkStore.apkFile(activity)
            val am = AssetManager::class.java.getDeclaredConstructor().newInstance()
            val add = AssetManager::class.java.getMethod("addAssetPath", String::class.java)
            val cookie = add.invoke(am, apk.absolutePath) as? Int ?: 0
            log(activity, "AssetManager.addAssetPath cookie=$cookie")

            val cur = activity.resources
            @Suppress("DEPRECATION")
            val res = Resources(am, cur.displayMetrics, cur.configuration)
            val f = ContextThemeWrapper::class.java.getDeclaredField("mResources")
            f.isAccessible = true
            f.set(activity, res)
            if (info.themeResId != 0) activity.setTheme(info.themeResId)
            log(activity, "Resources swapped (theme=0x${Integer.toHexString(info.themeResId)})")
        } catch (t: Throwable) {
            log(activity, "ERROR swapping resources: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    fun registerHooks(app: Application) {
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityPreCreated(activity: Activity, savedInstanceState: Bundle?) {
                log(activity, "PreCreated: ${activity.javaClass.name}")
                prepareActivity(activity)
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                if (Build.VERSION.SDK_INT < 29) prepareActivity(activity)
            }

            override fun onActivityStarted(activity: Activity) {}
            override fun onActivityResumed(activity: Activity) {
                log(activity, "Resumed: ${activity.javaClass.simpleName}")
            }

            override fun onActivityPaused(activity: Activity) {}
            override fun onActivityStopped(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}
